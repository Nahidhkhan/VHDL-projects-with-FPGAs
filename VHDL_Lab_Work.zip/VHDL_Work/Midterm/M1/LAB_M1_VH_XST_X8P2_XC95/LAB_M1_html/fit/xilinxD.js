var XilinxD="file:///D:/VHDL_Soft_installed/Xilinx/chipviewer/lib/download.htm";
